package com.assessment.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/assessment_system";

    private static final String USER = "root";

    private static final String PASSWORD = "Sujith@002";

    public static Connection getConnection() throws SQLException {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver was not found.", e);
        }

        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
